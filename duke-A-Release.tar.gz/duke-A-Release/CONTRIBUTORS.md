# Contributors

Display | Name | Github Profile | Homepage
---|:---:|:---:|:---:
![](https://avatars0.githubusercontent.com/u/22460123?s=100) | Jeffry Lum | [Github](https://github.com/j-lum/) | [Homepage](https://se.kasugano.moe)
![](https://avatars0.githubusercontent.com/u/1673303?s=100) | Damith C. Rajapakse | [Github](https://github.com/damithc/) | [Homepage](https://www.comp.nus.edu.sg/~damithch/)
# I would like to join this list. How can I help the project

For more information, please refer to our [contributor's guide](https://oss-generic.github.io/process/).
